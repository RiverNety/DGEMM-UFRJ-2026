#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void multMatriz(size_t n, double* a, double* b, double* c) {
    for (size_t i = 0; i < n; i++) {
        for (size_t j = 0; j < n; j++) {
            for (size_t k = 0; k < n; k++) {
                c[(i * n) + j] += a[(i * n) + k] * b[(k * n) + j];
            }
        }
    }
}

void inicializar_1(size_t n, double* a) {
    for (size_t i = 0; i < n * n; i++) {
        a[i] = 1;
    }
}

void inicializar_0(size_t n, double* a) {
    for (size_t i = 0; i < n * n; i++) {
        a[i] = 0;
    }
}

int main(int argc, char* argv[]) {

    size_t n = 300;

    double* a = (double*)malloc(n * n * sizeof(double));
    double* b = (double*)malloc(n * n * sizeof(double));
    double* c = (double*)malloc(n * n * sizeof(double));


    inicializar_1(n, a);
    inicializar_1(n, b);

    double times[5];

    for(int i = 0; i < 5; i++) {
        inicializar_0(n, c);
        clock_t start = clock();
        multMatriz(n, a, b, c);
        clock_t stop = clock();

        double elapsed_time = (double)(stop - start) / CLOCKS_PER_SEC * 1000;
        times[i] = elapsed_time;
    }


    printf("\nvalores de tempo:\n");
    for(int i = 0; i < 5; i++) {
        printf(" %d: %.2f ms\n", i + 1, times[i]);
    }

    //da problema?

    free(a);
    free(b);
    free(c);

    return 0;
}